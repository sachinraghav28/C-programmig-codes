/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

/*#include <stdio.h>

int main()
{
    printf("Hello World");

    return 0;
}*/
/*#include<stdio.h>
int main()
{
    printf("name :sachin raghav\n");
    printf("class:b.tech\n");
    printf("uniol:2215500126");
    return 0;
}*/
/*#include <stdio.h>
void main()
{
    char a;
    float b;
    int c;
    printf("enter no");
    scanf("%c%f%d",&a,&b,&c);
    printf("a=%c\n b=%f\n c=%d\n",a,b,c);
    
    
}*/ 
#include <stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    printf("daimeter=%f,area=%f,cir=%f",2*a,3.14*a*a,2*3.14*a);
    return 0;
    
}


